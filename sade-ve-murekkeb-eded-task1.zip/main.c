/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int a;
    printf("1 eded daxil edin");
    scanf("%d",&a);
    if(a>=2){
        for(int i=1,say=0;i<=a;i++){
            if(a%i==0){
                say+=1;
            }
            if(say>2){
              printf("eded murekkebdir");
            }
            else{
              printf("eded sadedir");
            }
        }
    }
    else{
        printf("eded ne sadedir,ne murekkeb");
    }
    

    return 0;
}
