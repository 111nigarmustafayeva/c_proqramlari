/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,i=0,n;
    printf("1 eded daxil edin");
    scanf("%d",&a);
    while(a>0)
    {
        n=a%10;
        a/=10;
        i=i+1;
        printf("\nededin reqemi:%d",n);
    }
    printf("\nededin reqemleri sayi:%d",i);
    
    return 0;
}
